# DeZob Pharmaceutical Company — Advanced Marketplace Starter

This is a **starter project**, not a deployed or production-ready pharmacy marketplace.

## Included
- Next.js App Router + TypeScript starter
- Responsive DeZob marketplace landing page
- Supabase PostgreSQL schema for profiles, seller verification, listings, orders, order items, platform settings, subscriptions, ad placements, and audit logs
- Row Level Security (RLS) policies as a starting point
- Environment variable template
- Setup and production-readiness checklist

## Not yet live
This starter does not yet provide working registration, identity verification, checkout, payment collection, seller payouts, real advertising, subscriptions, order fulfillment, or mobile apps. Those require provider credentials, backend implementation, testing, and deployment. Never store card details yourself.

## Run locally
1. Install Node.js 20+ on a computer.
2. Extract the project.
3. Run `npm install`.
4. Copy `.env.example` to `.env.local` and fill in your Supabase project values.
5. Run `npm run dev`.
6. Open `http://localhost:3000`.

If you only have an Android phone, you can edit the project in a cloud development environment, but deployment and secure configuration are easier with a computer.

## Create Supabase database
1. Create a Supabase project.
2. Open SQL Editor.
3. Run `supabase/schema.sql`.
4. Configure Auth email confirmation and allowed redirect URLs.
5. Add environment variables to your hosting provider.

## Before public launch
- Implement server-side authorization and validate every input.
- Implement Supabase Auth flows and account recovery.
- Add seller KYB/KYC and manual review.
- Integrate a payment provider that supports the seller's country and marketplace split/payout model.
- Verify payment webhooks server-side; never trust a browser success message.
- Restrict medicine listings by country, product type, license, and prescription status. Do not allow controlled/restricted products without a lawful, compliant workflow.
- Add privacy policy, terms, refund/returns, seller agreement, moderation and complaint processes.
- Conduct security review, backups, logging, accessibility and load testing.
- Test taxes, currencies, shipping, fraud controls and consumer-protection obligations in each target market.

## Monetization model
Suggested initial settings:
- Commission: configurable per category (do not hard-code a percentage)
- Seller subscription plans: free and paid tiers
- Promoted listings: clearly labelled advertisements
- Optional seller listing fees
All fees should be disclosed before a seller lists or a customer pays.
