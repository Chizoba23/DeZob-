-- DeZob Marketplace starter schema.
-- Review and adapt policies before production. Do not treat this schema alone as a complete security review.
create extension if not exists pgcrypto;

create type public.account_role as enum ('customer', 'seller', 'admin');
create type public.seller_status as enum ('not_applied', 'pending', 'approved', 'rejected', 'suspended');
create type public.listing_status as enum ('draft', 'pending_review', 'active', 'rejected', 'paused', 'removed');
create type public.order_status as enum ('pending_payment', 'paid', 'processing', 'shipped', 'completed', 'cancelled', 'refunded');
create type public.product_kind as enum ('medicine', 'medical_device', 'personal_care', 'service', 'other');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  country_code char(2),
  preferred_currency char(3) default 'USD',
  role public.account_role not null default 'customer',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.seller_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  legal_business_name text not null,
  country_code char(2) not null,
  license_reference text,
  status public.seller_status not null default 'pending',
  reviewer_notes text,
  submitted_at timestamptz not null default now(),
  reviewed_at timestamptz
);

create table public.listings (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id),
  title text not null check (char_length(title) between 3 and 160),
  description text not null default '',
  kind public.product_kind not null,
  category text not null,
  country_code char(2) not null,
  currency char(3) not null,
  price_minor bigint not null check (price_minor >= 0),
  stock_quantity integer check (stock_quantity is null or stock_quantity >= 0),
  image_urls text[] not null default '{}',
  manufacturer text,
  pack_size text,
  prescription_required boolean not null default false,
  license_verified boolean not null default false,
  status public.listing_status not null default 'draft',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.profiles(id),
  status public.order_status not null default 'pending_payment',
  currency char(3) not null,
  subtotal_minor bigint not null check (subtotal_minor >= 0),
  shipping_minor bigint not null default 0 check (shipping_minor >= 0),
  tax_minor bigint not null default 0 check (tax_minor >= 0),
  platform_fee_minor bigint not null default 0 check (platform_fee_minor >= 0),
  total_minor bigint not null check (total_minor >= 0),
  payment_provider text,
  provider_payment_reference text unique,
  shipping_country char(2),
  created_at timestamptz not null default now()
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  listing_id uuid references public.listings(id),
  seller_id uuid not null references public.profiles(id),
  title_snapshot text not null,
  quantity integer not null check (quantity > 0),
  unit_price_minor bigint not null check (unit_price_minor >= 0),
  platform_fee_minor bigint not null default 0 check (platform_fee_minor >= 0)
);

create table public.platform_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);

create table public.seller_subscriptions (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id),
  plan_code text not null,
  status text not null check (status in ('incomplete','active','past_due','cancelled','expired')),
  provider_subscription_reference text unique,
  current_period_end timestamptz,
  created_at timestamptz not null default now()
);

create table public.ad_placements (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id),
  listing_id uuid references public.listings(id),
  placement_code text not null,
  status text not null default 'pending' check (status in ('pending','active','paused','ended')),
  starts_at timestamptz,
  ends_at timestamptz,
  budget_minor bigint not null default 0 check (budget_minor >= 0),
  currency char(3) not null,
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id),
  action text not null,
  entity_type text not null,
  entity_id text,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.seller_applications enable row level security;
alter table public.listings enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.platform_settings enable row level security;
alter table public.seller_subscriptions enable row level security;
alter table public.ad_placements enable row level security;
alter table public.audit_logs enable row level security;

-- Profiles: users can read/update only their own profile. Never allow self-promotion to admin.
create policy "profile read own" on public.profiles for select using (auth.uid() = id);
create policy "profile update own" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);

-- Approved listings can be viewed publicly; sellers can manage only their own listings.
create policy "active listings public read" on public.listings for select using (status = 'active');
create policy "seller read own listings" on public.listings for select using (auth.uid() = seller_id);
create policy "seller create own draft listings" on public.listings for insert with check (auth.uid() = seller_id and status in ('draft','pending_review'));
create policy "seller update own non-active listings" on public.listings for update using (auth.uid() = seller_id and status in ('draft','pending_review','paused')) with check (auth.uid() = seller_id);

create policy "seller application read own" on public.seller_applications for select using (auth.uid() = user_id);
create policy "user submit seller application" on public.seller_applications for insert with check (auth.uid() = user_id and status = 'pending');

create policy "customer read own orders" on public.orders for select using (auth.uid() = customer_id);
create policy "customer read own order items" on public.order_items for select using (
  exists (select 1 from public.orders o where o.id = order_id and o.customer_id = auth.uid())
  or seller_id = auth.uid()
);
create policy "seller read own subscriptions" on public.seller_subscriptions for select using (auth.uid() = seller_id);
create policy "seller read own ad placements" on public.ad_placements for select using (auth.uid() = seller_id);

-- Intentionally no client-side policies for creating paid orders, changing payment status,
-- payouts, platform settings, audit logs, or moderation decisions. These must go through
-- trusted server endpoints after authorization and verified payment-provider webhooks.
