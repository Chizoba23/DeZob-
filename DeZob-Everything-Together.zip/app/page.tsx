const categories = [
  { icon: "💊", name: "Pharmacy products", desc: "Only where legally permitted" },
  { icon: "🩺", name: "Medical equipment", desc: "Tools for care professionals" },
  { icon: "🧴", name: "Personal care", desc: "Everyday wellness essentials" },
  { icon: "🧑‍⚕️", name: "Pharmacy services", desc: "Connect with eligible providers" },
];

const features = [
  ["Verified sellers", "Seller applications and documentation review before eligible listings go live."],
  ["Clear product details", "Show manufacturer, pack size, country availability, warnings and seller information."],
  ["Protected transactions", "Checkout must be handled by a supported payment provider with verified server-side webhooks."],
  ["Global-ready design", "Prepare for multiple currencies, country rules, shipping and local compliance."],
];

export default function Home() {
  return (
    <main>
      <div className="topbar"><span>DeZob Pharmaceutical Company</span><span>Trust · Care · Innovation</span></div>
      <header className="nav wrap">
        <a className="brand" href="#"><span className="brandmark">D+</span><span>DeZob<span className="brandlight">Market</span><small>HEALTH & PHARMACY</small></span></a>
        <nav><a href="#categories">Categories</a><a href="#how">How it works</a><a href="#sellers">For sellers</a></nav>
        <a className="navbutton" href="#join">Get started <span>↗</span></a>
      </header>

      <section className="hero wrap">
        <div className="hero-copy">
          <div className="eyebrow"><span className="dot" /> A marketplace built around trust</div>
          <h1>Health essentials.<br/><em>Better connected.</em></h1>
          <p className="lead">Discover pharmacy and healthcare products from sellers who meet the requirements for the markets they serve.</p>
          <div className="hero-actions"><a className="primary" href="#categories">Explore categories <span>→</span></a><a className="secondary" href="#sellers">Become a seller</a></div>
          <div className="trustline"><span>✓ Seller review process</span><span>✓ Clear product information</span></div>
        </div>
        <div className="hero-art">
          <div className="orb orb1"></div><div className="orb orb2"></div>
          <div className="medical-card">
            <div className="card-top"><span className="mini-logo">D+</span><span className="status">MARKETPLACE CONCEPT</span></div>
            <div className="cross">✚</div>
            <h3>Care, connected.</h3><p>Designed for responsible healthcare commerce.</p>
            <div className="pillrow"><span className="pill pillblue"></span><span className="pill pillgreen"></span><span className="pill pillwhite"></span></div>
          </div>
          <div className="float-tag tag1">✓ Seller verification workflow</div>
          <div className="float-tag tag2">🌍 Built for multiple markets</div>
        </div>
      </section>

      <section className="stats wrap">
        <div><strong>One</strong><span>shared platform vision</span></div><div><strong>Web + mobile</strong><span>planned across devices</span></div><div><strong>Compliance-first</strong><span>country-aware product rules</span></div>
      </section>

      <section className="section wrap" id="categories">
        <div className="sectionhead"><div><div className="eyebrow">EXPLORE THE MARKET</div><h2>Care starts with <em>confidence.</em></h2></div><p>Categories shown here are a design preview. Listings must be reviewed and enabled according to local law.</p></div>
        <div className="categorygrid">{categories.map((c) => <article className="category" key={c.name}><div className="caticon">{c.icon}</div><h3>{c.name}</h3><p>{c.desc}</p><span className="arrow">↗</span></article>)}</div>
      </section>

      <section className="how" id="how"><div className="wrap section"><div className="eyebrow">BUILT FOR RESPONSIBLE COMMERCE</div><h2>A better experience for <em>every side.</em></h2><div className="featuregrid">{features.map(([title, desc], i) => <article className="feature" key={title}><span className="number">0{i+1}</span><h3>{title}</h3><p>{desc}</p></article>)}</div></div></section>

      <section className="seller wrap" id="sellers"><div><div className="eyebrow">FOR APPROVED SELLERS</div><h2>Grow your business.<br/><em>Earn customer trust.</em></h2><p>Seller tools will support listings, orders, fee transparency, and performance reporting once the backend is implemented.</p></div><div className="sellerbox"><div className="sellerbox-icon">↗</div><h3>Seller dashboard</h3><ul><li>Manage product listings</li><li>Track orders and status</li><li>View fees and earnings</li><li>Apply for seller verification</li></ul><a href="#join" className="primary">Seller onboarding plan →</a></div></section>

      <section className="join wrap" id="join"><div><div className="eyebrow">THE NEXT STEP</div><h2>Build the trusted<br/><em>DeZob experience.</em></h2><p>This is the first visual foundation. Account access, checkout, seller payouts and listings are not active yet.</p></div><div className="joinpanel"><strong>Marketplace foundation</strong><p>Next: configure Supabase, secure account flows, seller review, product moderation, and payment-provider integration.</p><a className="secondary" href="https://supabase.com" target="_blank" rel="noreferrer">Explore Supabase ↗</a></div></section>

      <footer><div className="wrap foot"><a className="brand" href="#"><span className="brandmark">D+</span><span>DeZob<span className="brandlight">Market</span><small>HEALTH & PHARMACY</small></span></a><p>Concept starter · Not a live pharmacy or payment service.</p><span>© {new Date().getFullYear()} DeZob</span></div></footer>
    </main>
  );
}
