import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "DeZob | Health & Pharmacy Marketplace",
  description: "Discover trusted pharmacy and healthcare products from verified sellers.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
