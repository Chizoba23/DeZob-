# DeZob Marketplace — Combined Package

This package contains both:
1. `index.html` — a standalone responsive website demo that can be deployed as a static site.
2. The `app/`, `lib/`, and `supabase/` folders — a Next.js + TypeScript + Supabase advanced starter foundation.

## Quickest way to publish the demo
For a simple preview on Netlify, upload **only `index.html`** or put it in a folder and upload that folder as a static site. The HTML demo has sample product cards, category filters, search, and a demo cart.

## Run the advanced starter
The Next.js project needs Node.js 20+ and a computer or cloud development environment:
- Install dependencies with `npm install`
- Copy `.env.example` to `.env.local`
- Add your Supabase project URL and anon key
- Run `npm run dev`
- Apply `supabase/schema.sql` in the Supabase SQL Editor

## Important limitations
Neither version is yet a production-ready commercial marketplace. The static HTML cart is only a demo. The advanced starter includes a database schema and starter policies, but real authentication flows, product moderation, secure order APIs, payment-provider integration, verified payment webhooks, seller payouts, subscriptions, live advertising, and native Android/iOS apps still need implementation and testing.

For pharmacy products, enable listings only where permitted and add country-specific seller licensing, prescription controls, product restrictions, privacy protections, and consumer-protection processes. Do not handle payment card data directly; use an appropriate payment provider.
